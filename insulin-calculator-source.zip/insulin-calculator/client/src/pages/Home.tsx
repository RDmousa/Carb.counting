import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, Pill, Droplet, Calculator } from "lucide-react";

/**
 * Design Philosophy: Modern Medical Balance
 * - Clear medical color scheme (green & blue)
 * - Immediate feedback on calculations
 * - Professional yet accessible interface
 * - Organized tab-based navigation
 */

export default function Home() {
  // TDD Calculator
  const [weight, setWeight] = useState<number | string>("");
  const [tddMethod, setTddMethod] = useState<"standard" | "manual">("standard");
  const [tddManualValue, setTddManualValue] = useState<number | string>("");
  const tddResult = tddMethod === "standard" && weight ? (Number(weight) * 0.5).toFixed(1) : tddManualValue;

  // ICR Calculator
  const [icrRule, setIcrRule] = useState<"500" | "450" | "350">("500");
  const [carbs, setCarbs] = useState<number | string>("");
  const icrDivisor = { "500": 5, "450": 4.5, "350": 3.5 }[icrRule];
  const icrResult = carbs ? (Number(carbs) / icrDivisor).toFixed(1) : "";

  // Carb Coverage Calculator
  const [carbsCoverage, setCarbsCoverage] = useState<number | string>("");
  const [icrValue, setIcrValue] = useState<number | string>("");
  const carbCoverageResult = carbsCoverage && icrValue ? (Number(carbsCoverage) / Number(icrValue)).toFixed(1) : "";

  // ISF Calculator
  const [isfRule, setIsfRule] = useState<"1500" | "1800">("1500");
  const [currentSugar, setCurrentSugar] = useState<number | string>("");
  const [targetSugar, setTargetSugar] = useState<number | string>("");
  const isfDivisor = isfRule === "1500" ? 1500 : 1800;
  const isfResult = currentSugar && targetSugar ? ((Number(currentSugar) - Number(targetSugar)) / isfDivisor).toFixed(1) : "";

  // Correction Dose Calculator
  const [correctionSugar, setCorrectionSugar] = useState<number | string>("");
  const [correctionTarget, setCorrectionTarget] = useState<number | string>("");
  const [isf, setIsf] = useState<number | string>("");
  const correctionResult = correctionSugar && correctionTarget && isf ? ((Number(correctionSugar) - Number(correctionTarget)) / Number(isf)).toFixed(1) : "";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 shadow-sm">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-emerald-100 p-3 rounded-lg">
              <Activity className="w-6 h-6 text-emerald-700" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900">حاسبة الأنسولين والكاربوهيدرات</h1>
          </div>
          <p className="text-slate-600 text-sm">أداة طبية متقدمة لحساب جرعات الأنسولين بناءً على معايير طبية موثوقة</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="tdd" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8 bg-white border border-slate-200 p-1 rounded-lg shadow-sm">
            <TabsTrigger value="tdd" className="text-xs sm:text-sm">الجرعة اليومية</TabsTrigger>
            <TabsTrigger value="icr" className="text-xs sm:text-sm">نسبة الأنسولين</TabsTrigger>
            <TabsTrigger value="coverage" className="text-xs sm:text-sm">تغطية الكاربوهيدرات</TabsTrigger>
            <TabsTrigger value="isf" className="text-xs sm:text-sm">حساسية الأنسولين</TabsTrigger>
            <TabsTrigger value="correction" className="text-xs sm:text-sm">جرعة التصحيح</TabsTrigger>
          </TabsList>

          {/* TDD Calculator */}
          <TabsContent value="tdd" className="space-y-6">
            <Card className="p-6 border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Pill className="w-5 h-5 text-emerald-600" />
                <h2 className="text-xl font-semibold text-slate-900">حاسبة الجرعة اليومية (TDD)</h2>
              </div>
              <p className="text-slate-600 text-sm mb-6">حساب إجمالي الجرعة اليومية من الأنسولين بناءً على وزن الجسم</p>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">اختر طريقة الحساب</label>
                  <div className="flex gap-3">
                    <Button
                      variant={tddMethod === "standard" ? "default" : "outline"}
                      onClick={() => setTddMethod("standard")}
                      className="flex-1"
                    >
                      المعادلة القياسية (0.5 وحدة/كغ)
                    </Button>
                    <Button
                      variant={tddMethod === "manual" ? "default" : "outline"}
                      onClick={() => setTddMethod("manual")}
                      className="flex-1"
                    >
                      إدخال يدوي
                    </Button>
                  </div>
                </div>

                {tddMethod === "standard" && (
                  <div>
                    <label className="text-sm font-medium text-slate-700 block mb-2">وزن الجسم (كغ)</label>
                    <Input
                      type="number"
                      placeholder="أدخل وزنك بالكيلوغرام"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="border-slate-300"
                    />
                  </div>
                )}

                {tddMethod === "manual" && (
                  <div>
                    <label className="text-sm font-medium text-slate-700 block mb-2">الجرعة اليومية الإجمالية</label>
                    <Input
                      type="number"
                      placeholder="أدخل الجرعة"
                      value={tddManualValue}
                      onChange={(e) => setTddManualValue(e.target.value)}
                      className="border-slate-300"
                    />
                  </div>
                )}
              </div>

              {tddResult && (
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-slate-600 mb-2">الجرعة اليومية الإجمالية</p>
                  <p className="text-4xl font-bold text-emerald-700">{tddResult}</p>
                  <p className="text-xs text-slate-500 mt-2">الجرعة = الوزن × 0.5</p>
                  <p className="text-xs text-slate-600 mt-2">هذه الجرعة توزع على 3 حقن يومية (قبل الوجبات الثلاث)</p>
                </div>
              )}
            </Card>
          </TabsContent>

          {/* ICR Calculator */}
          <TabsContent value="icr" className="space-y-6">
            <Card className="p-6 border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Calculator className="w-5 h-5 text-emerald-600" />
                <h2 className="text-xl font-semibold text-slate-900">حاسبة نسبة الأنسولين للكاربوهيدرات (ICR)</h2>
              </div>
              <p className="text-slate-600 text-sm mb-6">حساب كمية الأنسولين المطلوبة لتغطية الكاربوهيدرات</p>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">اختر القاعدة</label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant={icrRule === "500" ? "default" : "outline"}
                      onClick={() => setIcrRule("500")}
                      className="text-xs"
                    >
                      قاعدة 500
                    </Button>
                    <Button
                      variant={icrRule === "450" ? "default" : "outline"}
                      onClick={() => setIcrRule("450")}
                      className="text-xs"
                    >
                      قاعدة 450
                    </Button>
                    <Button
                      variant={icrRule === "350" ? "default" : "outline"}
                      onClick={() => setIcrRule("350")}
                      className="text-xs"
                    >
                      قاعدة 350
                    </Button>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">كمية الكاربوهيدرات (غرام)</label>
                  <Input
                    type="number"
                    placeholder="أدخل كمية الكاربوهيدرات"
                    value={carbs}
                    onChange={(e) => setCarbs(e.target.value)}
                    className="border-slate-300"
                  />
                </div>
              </div>

              {icrResult && (
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-slate-600 mb-2">جرعة الأنسولين</p>
                  <p className="text-4xl font-bold text-emerald-700">{icrResult}</p>
                  <p className="text-xs text-slate-500 mt-2">الجرعة = الكاربوهيدرات ÷ ({icrDivisor})</p>
                  <p className="text-xs text-slate-600 mt-2">هذه الجرعة تغطي الكاربوهيدرات في الوجبة</p>
                </div>
              )}
            </Card>
          </TabsContent>

          {/* Carb Coverage Calculator */}
          <TabsContent value="coverage" className="space-y-6">
            <Card className="p-6 border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Droplet className="w-5 h-5 text-emerald-600" />
                <h2 className="text-xl font-semibold text-slate-900">حاسبة جرعة تغطية الكاربوهيدرات</h2>
              </div>
              <p className="text-slate-600 text-sm mb-6">حساب جرعة الأنسولين لتغطية الكاربوهيدرات في الوجبة</p>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">الكاربوهيدرات (غرام)</label>
                  <Input
                    type="number"
                    placeholder="أدخل الكاربوهيدرات"
                    value={carbsCoverage}
                    onChange={(e) => setCarbsCoverage(e.target.value)}
                    className="border-slate-300"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">نسبة الأنسولين للكاربوهيدرات (ICR)</label>
                  <Input
                    type="number"
                    placeholder="أدخل ICR (مثال: 10)"
                    value={icrValue}
                    onChange={(e) => setIcrValue(e.target.value)}
                    className="border-slate-300"
                  />
                </div>
              </div>

              {carbCoverageResult && (
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-slate-600 mb-2">جرعة التغطية</p>
                  <p className="text-4xl font-bold text-emerald-700">{carbCoverageResult}</p>
                  <p className="text-xs text-slate-500 mt-2">الجرعة = الكاربوهيدرات ÷ ICR</p>
                  <p className="text-xs text-slate-600 mt-2">تستخدم لتغطية الكاربوهيدرات في الوجبة</p>
                </div>
              )}
            </Card>
          </TabsContent>

          {/* ISF Calculator */}
          <TabsContent value="isf" className="space-y-6">
            <Card className="p-6 border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-5 h-5 text-emerald-600" />
                <h2 className="text-xl font-semibold text-slate-900">حاسبة حساسية الأنسولين (ISF)</h2>
              </div>
              <p className="text-slate-600 text-sm mb-6">حساب تأثير وحدة الأنسولين على مستوى السكر في الدم</p>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">اختر القاعدة</label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant={isfRule === "1500" ? "default" : "outline"}
                      onClick={() => setIsfRule("1500")}
                      className="text-xs"
                    >
                      قاعدة 1500
                    </Button>
                    <Button
                      variant={isfRule === "1800" ? "default" : "outline"}
                      onClick={() => setIsfRule("1800")}
                      className="text-xs"
                    >
                      قاعدة 1800
                    </Button>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">السكر الحالي (ملغ/ديسيلتر)</label>
                  <Input
                    type="number"
                    placeholder="أدخل السكر الحالي"
                    value={currentSugar}
                    onChange={(e) => setCurrentSugar(e.target.value)}
                    className="border-slate-300"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">السكر المستهدف (ملغ/ديسيلتر)</label>
                  <Input
                    type="number"
                    placeholder="أدخل السكر المستهدف"
                    value={targetSugar}
                    onChange={(e) => setTargetSugar(e.target.value)}
                    className="border-slate-300"
                  />
                </div>
              </div>

              {isfResult && (
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-slate-600 mb-2">جرعة الأنسولين</p>
                  <p className="text-4xl font-bold text-emerald-700">{isfResult}</p>
                  <p className="text-xs text-slate-500 mt-2">الجرعة = (السكر الحالي - السكر المستهدف) ÷ {isfDivisor}</p>
                  <p className="text-xs text-slate-600 mt-2">تستخدم لخفض مستوى السكر المرتفع</p>
                </div>
              )}
            </Card>
          </TabsContent>

          {/* Correction Dose Calculator */}
          <TabsContent value="correction" className="space-y-6">
            <Card className="p-6 border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Pill className="w-5 h-5 text-emerald-600" />
                <h2 className="text-xl font-semibold text-slate-900">حاسبة جرعة التصحيح</h2>
              </div>
              <p className="text-slate-600 text-sm mb-6">حساب جرعة الأنسولين لتصحيح ارتفاع السكر</p>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">السكر الحالي (ملغ/ديسيلتر)</label>
                  <Input
                    type="number"
                    placeholder="أدخل السكر الحالي"
                    value={correctionSugar}
                    onChange={(e) => setCorrectionSugar(e.target.value)}
                    className="border-slate-300"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">السكر المستهدف (ملغ/ديسيلتر)</label>
                  <Input
                    type="number"
                    placeholder="أدخل السكر المستهدف"
                    value={correctionTarget}
                    onChange={(e) => setCorrectionTarget(e.target.value)}
                    className="border-slate-300"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-slate-700 block mb-2">حساسية الأنسولين (ISF)</label>
                  <Input
                    type="number"
                    placeholder="أدخل ISF"
                    value={isf}
                    onChange={(e) => setIsf(e.target.value)}
                    className="border-slate-300"
                  />
                </div>
              </div>

              {correctionResult && (
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-slate-600 mb-2">جرعة التصحيح</p>
                  <p className="text-4xl font-bold text-emerald-700">{correctionResult}</p>
                  <p className="text-xs text-slate-500 mt-2">الجرعة = (السكر الحالي - السكر المستهدف) ÷ ISF</p>
                  <p className="text-xs text-slate-600 mt-2">تستخدم لتصحيح ارتفاع سكر الدم وإعادته إلى المستوى الطبيعي</p>
                </div>
              )}
            </Card>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="mt-12 p-6 bg-white border border-slate-200 rounded-lg shadow-sm text-center">
          <p className="text-xs text-slate-600 mb-2">
            <strong>تنبيه طبي:</strong> هذه الأداة للاستخدام الطبي المتخصص فقط
          </p>
          <p className="text-xs text-slate-500">جميع الحسابات تقريبية وتستلزم مراجعة الطبيب المختص</p>
          <p className="text-xs text-slate-500 mt-3">من إعداد: CLINICAL DIETICIAN RESIDENT - MOUSA ALOWIMRI, RD</p>
        </div>
      </div>
    </div>
  );
}
